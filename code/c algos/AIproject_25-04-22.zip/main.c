#include "carsharing.h"
#include <errno.h>
#include "utilities.h"
#include <time.h>

int main(int argc, char** argv)
{
	//variable to be used to store "parse_command_line" return value
	int pcl = 0;
	Instance instance;
	//if pcl == 0 then generate random coordinates, else the file must have specified the coordinates
	pcl = parse_command_line(argc, argv, &instance);
	if (pcl)
	{
		readInputDimension(&instance);
		fastReadInput(&instance);
	}
	// allocation of some data structures
	instance.xcoord = (double*)calloc(instance.nnodes, sizeof(double));
	instance.ycoord = (double*)calloc(instance.nnodes, sizeof(double));
	instance.dist = (double*)calloc(instance.nnodes * instance.nnodes, sizeof(double));
	instance.best_sol = (int*)calloc(instance.nnodes, sizeof(int));

	// setting a flag value which will become useful during the path search
	for (int i = 0; i < instance.nnodes; i++)
	{
		for (int j = 0; j < instance.nnodes; j++)
		{
			instance.dist[i * instance.nnodes + j] = -1.0;
		}
	}
	
	// allocation of other data structures
	Driver* drivers = (Driver*)calloc(instance.numDrivers, sizeof(Driver));
	Rider* riders = (Rider*)calloc(instance.numRiders, sizeof(Rider));
	for (int i = 0; i < instance.numDrivers; i++)
	{
		drivers[i].path = (int*)calloc(instance.nnodes, sizeof(int));
		drivers[i].driverNumber = i + 1;
		drivers[i].nearestRiders = (int*)calloc(instance.numRiders, sizeof(int));
	}
	if (pcl)
	{
		read_input(&instance, drivers, riders);
	}
	else
	{
		//generate_random_points(&instance);
		//strcpy(instance.solution_file, "randomPoints_");
		/*for (int i = 0; i < numDrivers; i++)
		{
			drivers[i].path = (int*)calloc(instance.nnodes, sizeof(int));
			drivers[i].driverNumber = i + 1;
			drivers[i].nearestRiders = (int*)calloc(instance.numRiders, sizeof(int));
		}
		generateDR(&instance, drivers, riders, numDrivers, numRiders);*/
	}
	
	if (strcmp(instance.method, "cplex") == 0)
	{
		clock_t begin = clock();
		int* p = NULL;
		//CSopt(&instance, drivers, riders, instance.numDrivers);
		clock_t end = clock();
		printf("\nElapsed time: %f\n", (double)((end - begin)) / CLOCKS_PER_SEC);
	}

	if (strcmp(instance.method, "greedy") == 0)
	{
		for (int i = 0; i < instance.numDrivers; i++)
		{
			//printf("Driver %d starting node is: %d\n", i, drivers[i].startingNode);
			greedSearch(&instance, drivers, i, riders);
		}
	}
	
	free(instance.best_sol);
	free(instance.xcoord);
	free(instance.ycoord);
	free(instance.dist);
	free(riders);
	if (pcl == 1)
	{
		for (int i = 0; i < instance.numDrivers; i++)
		{
			free(drivers[i].path);
			free(drivers[i].nearestRiders);
		}
	}
	free(drivers);
}
