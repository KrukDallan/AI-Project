#include "carsharing.h"
#include <errno.h>
#include "utilities.h"
#include <time.h>

int main(int argc, char** argv)
{
	//variable to be used to store "parse_command_line" return value
	int pcl = 0;
	Instance instance;
	//if pcl == 0 then generate random coordinates, else the file must have specified the coordinates
	pcl = parse_command_line(argc, argv, &instance);
	if (pcl)
	{
		fastReadInput(&instance);
	}
	// allocation of some data structures
	/*instance.xcoord = (double*)calloc(instance.nnodes, sizeof(double));
	instance.ycoord = (double*)calloc(instance.nnodes, sizeof(double));
	instance.dist = (double*)calloc(instance.nnodes * instance.nnodes, sizeof(double));
	instance.best_sol = (int*)calloc(instance.nnodes, sizeof(int));*/
	
	// allocation of drivers data structure
	Driver* drivers = (Driver*)calloc(instance.numberOfDrivers, sizeof(Driver)); // get the number from the input file first
	if (pcl)
	{
		//read_input(&instance, drivers, numDriver);
	}
	else
	{
		return -1;
		//generate_random_points(&instance);
		//strcpy(instance.solution_file, "randomPoints_");
		/*for (int i = 0; i < numDrivers; i++)
		{
			drivers[i].path = (int*)calloc(instance.nnodes, sizeof(int));
			drivers[i].driverNumber = i + 1;
			drivers[i].nearestRiders = (int*)calloc(instance.numRiders, sizeof(int));
		}
		generateDR(&instance, drivers, riders, numDrivers, numRiders);*/
	}
	
	if (strcmp(instance.method, "cplex") == 0)
	{
		clock_t begin = clock();
		for (int i = 0; i < instance.numberOfDrivers; i++)
		{
			read_input(&instance, drivers, i);
			drivers[i].startingNode = drivers[i].path[0];
			drivers[i].arrivalNode = drivers[i].path[drivers[i].pathCardinality - 1];
			CSopt(&instance, drivers, i);
		}
		clock_t end = clock();
		printf("\nElapsed time: %f\n", (double)((end - begin)) / CLOCKS_PER_SEC);
	}

	
	/*FILE* fout = fopen("plotting.dat", "w");
	double solution[1000];
	int flag = 0;
	for (int i = 0; i < instance.nnodes; i++)
	{
		for (int j = i + 1; j < instance.nnodes - 1; j++)
		{
			if (instance.dist[i * instance.nnodes + j] != -1)
			{
				if (flag == 0)
				{
					snprintf(solution, sizeof(solution), "%f%s%f%s", instance.xcoord[i], " ", instance.ycoord[i], "\n");
					fputs(solution, fout);
				}
				flag = 1;
				snprintf(solution, sizeof(solution), "%f%s%f%s", instance.xcoord[j], " ", instance.ycoord[j], "\n");
				fputs(solution, fout);
			}
		}
		flag = 0;
	}
	fclose(fout);
	plot("plotting.dat", 0);*/
	
	free(instance.xcoord);
	free(instance.ycoord);
	free(instance.dist);
	if (pcl == 1)
	{
		for (int i = 0; i < instance.numberOfDrivers; i++)
		{
			free(drivers[i].path);
			free(drivers[i].pickUpRidersNodes);
		}
	}
	free(drivers);
}
