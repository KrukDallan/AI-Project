#include "utilities.h"
#define MIN(a,b) ( ((a) < (b)) ? (a) : (b) )

void free_memory(Instance* instance)
{
	free(instance->xcoord);
	free(instance->ycoord);
	free(instance->dist);
}

int parse_command_line(int argc, char** argv, Instance* instance)
{
	int return_value = 0;
	//default values
	strcpy(instance->input_file, "NULL");
	//printf("Number of args: %d", argc);
	//printf("%s", *argv);

	for (int i = 1; i < argc; i++)
	{
		if (strcmp("-f", argv[i]) == 0)
		{
			strcpy(instance->input_file, argv[++i]);
			return_value += 1;
			continue;
		}
		if (strcmp("-C", argv[i]) == 0) //Cplex
		{
			strcpy(instance->method, argv[++i]);
			continue;
		}
		if (strcmp("-r", argv[i]) == 0) //random nodes
		{
			char* num = argv[++i];
			instance->nrnodes = atoi(num);
			printf("Number of random nodes: %d\n", instance->nrnodes);
		}
	}
	return return_value;
}

void read_input(Instance* instance,  Driver* drivers, int numDriver)
{
	FILE* finput = fopen(instance->input_file, "r");
	//FILE* fout = fopen("Output.txt", "w");
	//buffer for fgets()
	char line[200];
	//pointer for strtok()
	char* token;
	//flag to start storing coordinates
	int coordinates = 0;
	int pathIndex = 0;

	char currentDriver[20] = "DRIVER";
	char driverNumber[5] = "";
	char neighborhood[30] = "";
	char roads[20] = "";
	char path[30] = "";
	char pathDim[30] = "";
	char currentRider[30] = "RIDER";
	sprintf(driverNumber, "%d", numDriver);
	strcat(currentDriver, driverNumber); // now currentDriver is something like DRIVER1
	
	sprintf(neighborhood, "%s", driverNumber);
	strcat(neighborhood, "NEIGHBORHOOD_DIM"); // 1NEIGHBORHOOD_DIM

	sprintf(roads, "%s", driverNumber);
	strcat(roads, "ROADS"); // 1ROADS

	sprintf(path, "%s", currentDriver);
	strcat(path, "_PATH");// DRIVER1_PATH

	sprintf(pathDim, "%s", driverNumber);
	strcat(pathDim, "PATH_DIM"); // 1PATH_DIM

	strcat(currentRider, driverNumber);
	strcat(currentRider, "_NODE"); // RIDER1_NODE

	while (fgets(line, 200, finput) != NULL)
	{
		token = strtok(line, " :");

		if (strncmp(token, "NAME", 4) == 0)
		{
			char* name = strtok(NULL, " :");
			printf("NAME: %s", name);
			coordinates = 0;
			int len = strlen(name);
			if (len > 0 && name[len - 1] == '\n') name[len - 1] = '\0';
			strcpy(instance->solution_file, name);
			strcat(strcat(instance->solution_file, instance->method),".dat");
			printf("%s\n", instance->solution_file);
			continue;
		}
		if (strcmp(token, currentDriver) == 0)
		{
			continue;
		}
		if (strcmp(token, neighborhood) == 0)
		{
			int n = atoi(strtok(NULL, " "));
			instance->nnodes = n;
			instance->xcoord = (double*)calloc(n, sizeof(double));
			instance->ycoord = (double*)calloc(n, sizeof(double));
			instance->dist = (double*)calloc((n * n), sizeof(double));
			for (int i = 0; i < n * n; i++)
			{
				instance->dist[i] = MAX_VAL;
			}
			coordinates = 1;

			continue;
		}
		if (strcmp(token, roads) == 0)
		{
			coordinates = 2;
			continue;
		}
		if (strcmp(token, pathDim) == 0)
		{
			int i = atoi(strtok(NULL, " "));
			drivers[numDriver].pathCardinality = i;
			drivers[numDriver].path = (int*)calloc(instance->nnodes, sizeof(int));
			drivers[numDriver].pickUpRidersNodes = (int*)calloc(2, sizeof(int));
			drivers[numDriver].npickUps = 1;
			coordinates = 3;
			continue;
		}
		if (strcmp(token, currentRider) == 0)
		{
			coordinates = 4;
			continue;
		}
		
		if (coordinates == 1)
		{
			char* x;
			char* y;
			//char out[100];
			int i = atoi(token); // node index
			if (i < 0 || i >= instance->nnodes)
			{
				coordinates = 0;
				continue;
			}
			x = strtok(NULL, " ");
			y = strtok(NULL, " ");
			instance->xcoord[i] = 111.32 * atof(x);
			instance->ycoord[i] = 40075 * cos(instance->xcoord[i])/360 * atof(y);
			//snprintf(out, sizeof(out), "%s%s%s%s%s%s", token, ": ", x, " ", y, "\n");
			//fputs(out, fout);
			//printf("Node %d at coordinates %f , %f\n", i, instance->xcoord[i], instance->ycoord[i]);
			continue;
		}

		if (coordinates == 2)
		{
			int p1 = atoi(token);
			char* tmp = strtok(NULL, " ");
			int p2 = atoi(tmp);
			double xdist = instance->xcoord[p1] - instance->xcoord[p2];
			double ydist = instance->ycoord[p1] - instance->ycoord[p2];
			double distance = sqrt(xdist * xdist + ydist * ydist);
			instance->dist[p1 * instance->nnodes + p2] = distance;
			instance->dist[p2 * instance->nnodes + p1] = distance;
			//printf("distance of %d and %d is: %f\n", p1, p2, instance->dist[p1 * instance->nnodes + p2]);
			continue;
		}

		if (coordinates == 3)
		{
			int i = atoi(token);
			drivers[numDriver].path[pathIndex] = i;
			pathIndex += 1;
			continue;
		}
		if (coordinates == 4)
		{
			int i = atoi(token);
			drivers[numDriver].pickUpRidersNodes[0] = i;
			drivers[numDriver].pickUpRidersNodes[1] = drivers[numDriver].path[pathIndex-1];
			break;
		}
	}
	fclose(finput);
	//fclose(fout);
}

void fastReadInput(Instance* instance) //just to save numDrivers & numRiders
{
	FILE* finput = fopen(instance->input_file, "r");
	//buffer for fgets()
	char line[200];
	//pointer for strtok()
	char* token;
	int driversFlag = 1; //precauzione
	int ridersFlag = 1;
	while (fgets(line, 200, finput) != NULL)
	{
		token = strtok(line, " :");
		if (strncmp(token, "DRIVERS", 7) == 0 && driversFlag == 1)
		{
			char* tmp = strtok(NULL, " :");
			instance->numberOfDrivers = atoi(tmp);
			driversFlag = 0;
			break;
		}
	}
	fclose(finput);
}

void readInputDimension(Instance* instance)
{
	FILE* finput = fopen(instance->input_file, "r");
	//buffer for fgets()
	char line[200];
	//pointer for strtok()
	char* token;
	while (fgets(line, 200, finput) != NULL)
	{
		token = strtok(line, " :");

		if (strncmp(token, "DIMENSION", 9) == 0)
		{
			char* tmp = strtok(NULL, " :");
			instance->nnodes = atoi(tmp);
			break;
		}
	}
	fclose(finput);

}

//void generate_random_points(Instance* instance)
//{
//	srand(10);
//	for (int i = 0; i < 1000; i++) rand();
//	
//	int n = instance->nrnodes;
//
//	instance->xcoord = (double*)calloc(n, sizeof(double));
//	instance->ycoord = (double*)calloc(n, sizeof(double));
//	for (int i = 0; i < n; i++)
//	{
//		instance->xcoord[i] = rand() % 6000;
//		instance->ycoord[i] = rand() % 6000;
//		//printf("Node %d at coordinates %f , %f\n", i, instance->xcoord[i], instance->ycoord[i]);
//	}
//	instance->nnodes = instance->nrnodes;
//
//}

//void generateDR(Instance* instance, Driver* drivers, Rider* riders, int numDrivers, int numRiders)
//{
//	int* isUsed = (int*)calloc(instance->nnodes, sizeof(int));
//
//	for (int i = 0; i < instance->nnodes; i++)
//	{
//		isUsed[i] = -1;
//	}
//
//	for (int i = 0; i < numDrivers; i++)
//	{
//		while (1)
//		{
//			int rv = rand() % instance->nnodes;
//			if (isUsed[rv] == -1)
//			{
//				drivers[i].startingNode = rv;
//				isUsed[rv] = 1;
//				break;
//			}
//		}
//	}
//	for (int i = 0; i < numDrivers; i++)
//	{
//		while (1)
//		{
//			int rv = rand() % instance->nnodes;
//			if (rv !=drivers[i].startingNode)
//			{
//				drivers[i].arrivalNode = rv;
//				break;
//			}
//		}
//	}
//	for (int i = 0; i < instance->nnodes; i++)
//	{
//		isUsed[i] = -1;
//	}
//	for (int i = 0; i < numRiders; i++) // to increase diversity
//	{
//		while (1)
//		{
//			int rv = rand() % instance->nnodes;
//			if (isUsed[rv] == -1)
//			{
//				riders[i].startingNode = rv;
//				isUsed[rv] = 1;
//				break;
//			}
//		}
//	}
//	for (int i = 0; i < numRiders; i++)
//	{
//		while (1)
//		{
//			int rv = rand() % instance->nnodes;
//			if (rv != riders[i].startingNode)
//			{
//				riders[i].arrivalNode = rv;
//				break;
//			}
//		}
//	}
//	free(isUsed);
//}

void distance(int i, int j, Instance* instance)
{
	if (i == j)
	{
		instance->dist[i * instance->nnodes + j] = 0;
	}
	else
	{
		double xdist = instance->xcoord[i] - instance->xcoord[j];
		double ydist = instance->ycoord[i] - instance->ycoord[j];
		double distance = sqrt(xdist * xdist + ydist * ydist);
		instance->dist[i * instance->nnodes + j] = distance;
	}

}

int findNode(Instance* instance, double xCoord)
{
	for (int i = 0; i < instance->nnodes; i++)
	{
		if (instance->xcoord[i] == xCoord)
		{
			return i;
		}
	}
}

void writeOnFile(Instance* instance, Driver drivers)
{
	FILE* fout = fopen(drivers.file, "w");
	//array in which we write the coordinates; may be useless because we can just use best_sol to get the coordinates.
	double solution[2000];

	//now the nodes in instance->best_sol are ordered : index 0 contains the first node, index 1 contains the successor of the node in position 0 and so on

	//this for and the two lines following it are used to write the minimum cost solution into the output file
	for (int i = 0; i <= drivers.pathCardinality; i++)
	{
		snprintf(solution, sizeof(solution), "%f%s%f%s", instance->xcoord[drivers.path[i]], " ", instance->ycoord[drivers.path[i]], "\n");
		fputs(solution, fout);
	}
	fclose(fout);
}

void updatePath(Instance* instance, Driver drivers, int riderNode)
{
	double dist = MAX_VAL;
	int pathNode = 0;
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		double tmp = instance->dist[drivers.path[i] * instance->nnodes + riderNode];
		if (tmp < dist)
		{
			dist = tmp;
			pathNode = i;
		}
	}
	int* stack = (int*)calloc(drivers.pathCardinality + 1, sizeof(int));
	int flag = 0;
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		if (flag)
		{
			stack[i + 1] = drivers.path[i];
		}
		else
		{
			stack[i] = drivers.path[i];
			if (i == pathNode)
			{
				stack[i + 1] = riderNode;
				flag = 1;
			}
		}
	}
	drivers.pathCardinality += 1;
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		drivers.path[i] = stack[i];
	}

	free(stack);
	writeOnFile(instance, drivers);
}

void plot(char* fileName, int driverNum)
{
	FILE* pipe = _popen("C:/Programmi/gnuplot/bin/gnuplot.exe -persist", "w");
	if (pipe != NULL)
	{
		fprintf(pipe, "plot '%s' with linespoints linestyle 6 \n", fileName);
		fflush(pipe);
	}
	else puts("Could not open the file\n");
	_pclose(pipe);
}


int minDistNode(Instance* instance, int node, int uncoveredNodes[], double* currentCost, int illegalNodes[])
{
	//printf("\nsn %d\n", node);
	int nn = instance->nnodes;
	int min_node_index = -1;
	double min_dist = MAX_VAL;
	for (int i = 0; i < nn; i++)
	{
		if (uncoveredNodes[i] != -1 && illegalNodes[i] != 1)
		{
			if (instance->dist[node * nn + uncoveredNodes[i]] > 0)
			{
				//printf("Distance from node %d is: %f\n", i, instance->dist[node * nn + uncoveredNodes[i]]);
				if (instance->dist[node * nn + uncoveredNodes[i]] < min_dist)
				{
					min_dist = instance->dist[node * nn + uncoveredNodes[i]];
					min_node_index = i;
					//printf("Node at local minimum distance is: %d\n", i);
				}
			}
		}
	}
	*currentCost = *currentCost + min_dist;
	return min_node_index;
}

void greedSearch(Instance* instance, Driver* drivers, int driverNumber, Rider* riders)
{
	int starting_node = drivers[driverNumber].startingNode;
	//will contain the current solution
	int* succ = (int*)calloc(instance->nnodes, sizeof(int));
	int* illegalNodes = (int*)calloc(instance->nnodes, sizeof(int));
	int* prev = (int*)calloc(instance->nnodes, sizeof(int));
	//will hold the index returned by min_dist_node
	int next_node_index = 0;

	//initialization of best_value
	drivers[driverNumber].cost = 0;
	int* uncovered_nodes = (int*)calloc(instance->nnodes, sizeof(int));

	for (int i = 0; i < instance->nnodes; i++)
	{
		//filling the uncovered_nodes array
		uncovered_nodes[i] = i;
		succ[i] = -1;
	}

	//setting the first element of the current solution as the starting node
	succ[0] = starting_node;

	//if j==size then j==47, so uncovered_nodes[j]=uncovered_nodes[size] is useless
	uncovered_nodes[starting_node] = -1;
	int size = 1;
	int prevSize = 0;

	// BACKTRACKING
	while (starting_node!=drivers[driverNumber].arrivalNode)
	{
		next_node_index = minDistNode(instance, starting_node, uncovered_nodes, &drivers[driverNumber].cost, illegalNodes);
		//printf("nni: %d\n", next_node_index);
		if (next_node_index == -1)
		{
			illegalNodes[starting_node] = 1;
			starting_node = prev[prevSize - 1];
			prevSize -= 1;
			succ[size - 1] = 0;
			size -= 1;
			continue;
		}
		succ[size] = uncovered_nodes[next_node_index];
		prev[prevSize] = starting_node;
		prevSize += 1;
		//re-assigning starting node so in the next call of min_dist_node the starting_node value passed will be the current "next_node"
		starting_node = uncovered_nodes[next_node_index];
		uncovered_nodes[next_node_index] = -1;
		size += 1;
	}
	for (int i = 0; i < size; i++)
	{
		printf("Node in position %d is: %d\n", i, succ[i]);
		drivers[driverNumber].path[i] = succ[i];
	}
	free(succ);
	free(uncovered_nodes);
	free(illegalNodes);
	free(prev);
	int i = 0;
}