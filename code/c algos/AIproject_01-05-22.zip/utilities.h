#ifndef UTILITIES_H
#define UTILITIES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "carsharing.h"
#include <math.h>
#include <limits.h>
#include <float.h>
#include <time.h>

#define MAX_VAL DBL_MAX;

int parse_command_line(int argc, char** argv, Instance* instance);
void read_input(Instance* instance, Driver* drivers, int numDriver);
// used to read number of drivers and riders
void fastReadInput(Instance* instance);
// used to read input dimension
void readInputDimension(Instance* instance);
//void generate_random_points(Instance* instance);
void free_memory(Instance* instance);

void distance(int i, int j, Instance* instance);
//return the # the node whose x coordinate is == xCoord
int findNode(Instance* instance, double xCoord); 
//void generateDR(Instance* instance, Driver* drivers, Rider* riders, int numDrives, int numRiders);
void plot(char* fileName, int driverNum);
void writeOnFile(Instance* instance, Driver drivers);

void updatePath(Instance* instance, Driver drivers, int riderNode);
int findNearestRiders(Instance* instance, Driver drivers, Rider* riders); // for a single driver
void greedSearch(Instance* instance, Driver* drivers, int driverNumber, Rider* riders);
int minDistNode(Instance* instance, int node, int uncoveredNodes[], double* currentCost, int illegalNodes[]);

#endif

