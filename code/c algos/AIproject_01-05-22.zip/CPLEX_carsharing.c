#include <cplex.h>  
#include "carsharing.h"
#include "utilities.h"
#define VERBOSE 10


void print_error(const char* err)
{
	printf("\n\n ERROR: %s \n\n", err);
	fflush(NULL);
	exit(1);
}

//other prototypes 

int xpos(int i, int j, Instance* inst)                                          
/***************************************************************************************************************************/
{
	if (i == j) print_error(" i == j in xpos");
	if (i > j)
	{
		int pos = i * inst->nnodes + j;
		return pos;
	}
	int pos = i * inst->nnodes + j;
	return pos;
}


/***************************************************************************************************************************/
void buildSTPModel(Instance* inst, CPXENVptr env, CPXLPptr lp, Driver drivers, int rootNode, int terminalSet[])
/**************************************************************************************************************************/
{

	double zero = 0.0;
	char binary = 'B';

	char** cname = (char**)calloc(1, sizeof(char*));		// (char **) required by cplex...
	cname[0] = (char*)calloc(100, sizeof(char));

	// add binary var.s x(i,j) for i < j  

	for (int i = 0; i < inst->nnodes; i++)
	{
		for (int j = 0; j < inst->nnodes; j++)
		{
			sprintf(cname[0], "x(%d,%d)", i + 1, j + 1);  		// ... x(1,2), x(1,3) ....
			double obj = inst->dist[i * inst->nnodes + j]; // cost == distance   
			double lb = 0.0;
			double ub = (i!=j) ? 1.0 : 0.0;
			if (CPXnewcols(env, lp, 1, &obj, &lb, &ub, &binary, cname)) print_error(" wrong CPXnewcols on x var.s");
			if (CPXgetnumcols(env, lp) - 1 != xpos(i, j, inst)) print_error(" wrong position for x var.s");
		}
	}

	// add the degree constraints 

	int* index = (int*)calloc(inst->nnodes, sizeof(int));
	double* value = (double*)calloc(inst->nnodes, sizeof(double));

	for (int h = 0; h < inst->nnodes; h++)  		// add the degree constraint on node h
	{
		double rhs;
		char sense = 'E'; // 'E' for equality constraint 
		if (h == drivers.startingNode)
		{
			rhs = 0.0;
		}
		else
		{
			rhs = 1.0;
			sense = 'L';
		}
		for (int k = 0; k < drivers.npickUps; k++)
		{
			if (h == terminalSet[k])
			{
				rhs = 1.0;
				sense = 'E';
				break;
			}
		}
		                           
		sprintf(cname[0], "degree(%d)", h + 1);
		int nnz = 0;
		for (int i = 0; i < inst->nnodes; i++)
		{
			if (i == h) continue;
			index[nnz] = xpos(i, h, inst); //posiion directed of h-i
			value[nnz] = 1.0;
			nnz++;
		}
		int izero = 0;
		if (CPXaddrows(env, lp, 0, 1, nnz, &rhs, &sense, &izero, index, value, NULL, &cname[0])) print_error("CPXaddrows(): error 1");
	}

	free(value);
	free(index);
	free(cname[0]);
	free(cname);

	if (VERBOSE >= 100)
	{
		int status = CPXwriteprob(env, lp, "model.lp", NULL);
		if (status)
		{
			printf("Status error: %d\n", status);
			exit(1);
		}
	}
	printf("Model built\n");
}

//#define DEBUG    // comment out to avoid debugging 
#define EPS 1e-5

// Bender's loop method:
// receives integer solution made of one or mode cycles
// when I enter the method I assume nonzero elements of xstar are one

/*********************************************************************************************************************************/
void build_sol(const double* xstar, Instance* inst, int* comp, int* pred, int* ncomp, Driver drivers) // build succ() and comp() wrt xstar()...
/*********************************************************************************************************************************/
{

#ifdef DEBUG // I check if degree of all nodes is two and if xstar does not contain fract. components
	int* degree = (int*)calloc(inst->nnodes, sizeof(int));
	for (int i = 0; i < inst->nnodes; i++)
	{
		for (int j = i + 1; j < inst->nnodes; j++)
		{
			int k = xpos(i, j, inst);
			if (fabs(xstar[k]) > EPS && fabs(xstar[k] - 1.0) > EPS) print_error(" wrong xstar in build_sol()");
			if (xstar[k] > 0.5)
			{
				++degree[i];
				++degree[j];
			}
		}
	}
	for (int i = 0; i < inst->nnodes; i++)
	{
		if (degree[i] != 2) print_error("wrong degree in build_sol()");
	}
	free(degree);
#endif

	printf("entered build_sol\n");
	for (int i = 0; i < inst->nnodes; i++)
	{
		pred[i] = -1;
		comp[i] = -1;
	}

	int tmp = drivers.startingNode;
	for (int start = 0; start < inst->nnodes; start++)
	{
		if (comp[start] >= 0) continue;  // node "start" was already visited, just skip it

		// a new component is found
		(*ncomp)++;
		int i = start;
		int done = 0;
		while (!done)  // go and visit the current component
		{
			comp[i] = *ncomp;
			done = 1;
			for (int j = 0; j < inst->nnodes; j++)
			{
				if (i != j && xstar[xpos(i, j, inst)] > 0.5 && comp[j] == -1) // the edge [i,j] is selected in xstar and j was not visited before 
				{
					pred[j] = i;
					i = j;
					done = 0;
					break;
				}
			}
		}
		pred[i] = start;  // last arc to close the cycle

		// go to the next component...
	}
	
}

/**************************************************************************************************************************/
int CSopt(Instance* inst, Driver* drivers, int driverNumber)
/**************************************************************************************************************************/
{
	// open CPLEX model
	int error;
	CPXENVptr env = CPXopenCPLEX(&error);
	if (error) print_error("CPXopenCPLEX() error");
	CPXLPptr lp = CPXcreateprob(env, &error, "CS model version 1");
	if (error) print_error("CPXcreateprob() error");

	buildSTPModel(inst, env, lp, drivers[driverNumber], drivers[driverNumber].startingNode, drivers[driverNumber].pickUpRidersNodes);

	// Cplex's parameter setting
	CPXsetintparam(env, CPX_PARAM_SCRIND, CPX_OFF);
	if (VERBOSE >= 60) CPXsetintparam(env, CPX_PARAM_SCRIND, CPX_ON); // Cplex output on screen
	CPXsetintparam(env, CPX_PARAM_RANDOMSEED, 123456);
	CPXsetdblparam(env, CPX_PARAM_TILIM, 3600.0);
	// ...

	error = CPXmipopt(env, lp);
	if (error)
	{
		printf("CPX error code %d\n", error);
		print_error("CPXmipopt() error");
	}

	// use the optimal solution found by CPLEX

	int ncols = CPXgetnumcols(env, lp);
	double* xstar = (double*)calloc(ncols, sizeof(double));
	error = CPXgetx(env, lp, xstar, 0, ncols - 1);
	if (error)
	{
		printf("CPXgetx() error: %d\n", error);
		print_error("CPXgetx() error");
	}
	//for (int i = 0; i < inst->nnodes; i++)
	//{
	//	for (int j = i + 1; j < inst->nnodes; j++)
	//	{
	//		//if (xstar[xpos(i, j, inst)] > 0.5) printf("  ... x(%3d,%3d) = 1\n", i + 1, j + 1);
	//	}
	//}
	int* pred = (int*)calloc(inst->nnodes, sizeof(int));
	int* comp = (int*)calloc(inst->nnodes, sizeof(int));
	int* index = (int*)calloc(ncols, sizeof(int));
	double* coeff = (double*)calloc(ncols, sizeof(double));
	int ncomp = 0;
	char sense = 'G';
	char** cname = (char**)calloc(1, sizeof(char*));		// (char **) required by cplex...
	cname[0] = (char*)calloc(inst->nnodes, sizeof(char));
	int izero = 0;
	int Sname = 0;
	while (1)
	{
		build_sol(xstar, inst, comp, pred, &ncomp, drivers[driverNumber]);
		int rootComponent = comp[drivers[driverNumber].startingNode];
		int counter = 0;
		for (int i = 0; i < drivers[driverNumber].npickUps + 1; i++) // +1 because npickUps contains the arrival node as well
		{
			int tmp = drivers[driverNumber].pickUpRidersNodes[i]; // tmp contains the node of the riders to be picked up
			if (comp[tmp] == comp[drivers[driverNumber].startingNode])
			{
				counter += 1;
			}
		}
		if (counter == drivers[driverNumber].npickUps + 1)
		{
			break; // we have the connected steiner tree
		}
		else
		{
			Sname += 1;
			int nnz = 0;
			double rhs = 0;
			for (int l = 0; l < ncols; l++)
			{
				index[l] = 0;
				coeff[l] = 0.0;
			}
			int rootComponent = comp[drivers[driverNumber].startingNode]; // set S
			for (int i = 0; i < inst->nnodes; i++)
			{
				for (int t = 0; t < inst->nnodes; t++)
				{
					if (comp[t] != rootComponent)
					{
						if (xstar[xpos(i, t, inst)] > 0.5)
						{
							rhs += 1;
						}
					}
				}
			}
			for (int i = 0; i < inst->nnodes; i++)
			{
				for (int j = 0; j < inst->nnodes; j++)
				{
					if (comp[i] == rootComponent && comp[j] != rootComponent)
					{
						index[nnz] = xpos(i, j, inst);
						coeff[nnz] = 1.0;
						nnz += 1;
						sprintf(cname[0], "S%d(%d,%d)", Sname, i + 1, j + 1);
					}
				}
			}
			if (CPXaddrows(env, lp, 0, 1, nnz, &rhs, &sense, &izero, index, coeff, NULL, &cname[0])) print_error("CPXaddrows(): error 1");
		}
		error = CPXmipopt(env, lp);
		ncols = CPXgetnumcols(env, lp);
		if (error)
		{
			printf("CPX error code %d\n", error);
			print_error("CPXmipopt() error");
		}
		error = CPXgetx(env, lp, xstar, 0, ncols - 1);
		if (error)
		{
			printf("CPX error code %d\n", error);
			print_error("CPXgetx() error");
		}
	}
	int i = 1;
	int tmp = drivers[driverNumber].path[0];
	for (i; i < inst->nnodes; i++)
	{
		for (int j = 0; j < inst->nnodes; j++)
		{
			if (pred[j] == tmp)
			{
				tmp = j;
				break;
			}
			else
			{
				tmp = -1; // flag value: no more nodes in the steiner tree, PERHAPS
			}
		}
		if (tmp == -1)
		{
			break;
		}
		drivers[driverNumber].path[i] = tmp;
	}
	drivers[driverNumber].pathCardinality = i;

	sprintf(drivers[driverNumber].file, "Path_of_driver%d.dat", driverNumber);
	if (driverNumber < 10)
	{
		drivers[driverNumber].file[15] = '\0';
	}
	else if (driverNumber > 9 && driverNumber < 100)
	{
		drivers[driverNumber].file[16] = '\0';
	}
	else
	{
		drivers[driverNumber].file[17] = '\0';
	}

	if (driverNumber == 1) writeOnFile(inst, drivers[driverNumber]);
	//plot(drivers[it].file, it);

	free(xstar);
	free(index);
	free(coeff);
	free(pred);
	free(comp);
	free(cname[0]);
	free(cname);
	// free and close cplex model   
	CPXfreeprob(env, &lp);
	CPXcloseCPLEX(&env);
	printf("Ended iteration %d\n", driverNumber);
	

	return 0; // or an appropriate nonzero error code
}
/***************************************************************************************************************************/
