#ifndef CS_H_

#define CS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {

	//basic components
	char input_file[200];
	char output_file[200];
	char solution_file[200];
	char cplex[20];
	
	//"dimension"
	int nnodes;
	//these pointers will point to an (future) allocated memory that will contain x and y coordinates
	double* xcoord;
	double* ycoord;
	double* dist;
	double best_value;
	double current_value;
	int* best_sol;
	int* best_succ;
	int starting_node;
	int arrival_node;

	// random generation
	int nrnodes;

	//number of drivers
	int numDrivers;

	//number of riders
	int numRiders;
} Instance;

typedef struct
{
	int driverNumber;
	int pathCardinality;
	int startingNode; // probably you'll need to find the node starting from the given coordinates
	int arrivalNode;
	int* path;
	int* nearestRiders;
	double radius;
	char file[200];
} Driver; // we will create an array of drivers

typedef struct
{
	int startingNode;
	int arrivalNode;
} Rider; // we will create an array of riders


#endif
