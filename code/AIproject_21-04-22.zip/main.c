#include "carsharing.h"
#include <errno.h>
#include "utilities.h"
#include <time.h>


// sarting node and arrival node initialized in CSopt

int main(int argc, char** argv)
{
	//variable to be used to store "parse_command_line" return value
	int pcl = 0;
	Instance instance;
	//if pcl == 0 then generate random coordinates, else the file must have specified the coordinates
	pcl = parse_command_line(argc, argv, &instance);

	int numDrivers = 3;
	int numRiders = 10;
	instance.numDrivers = numDrivers;
	instance.numRiders = numRiders;
	Driver* drivers = (Driver*)calloc(numDrivers, sizeof(Driver));
	Rider* riders = (Rider*)calloc(numRiders, sizeof(Rider));

	if (pcl)
	{
		read_input(&instance);
	}
	else
	{
		generate_random_points(&instance);
		strcpy(instance.solution_file, "randomPoints_");
		for (int i = 0; i < numDrivers; i++)
		{
			drivers[i].path = (int*)calloc(instance.nnodes, sizeof(int));
			drivers[i].driverNumber = i + 1;
			drivers[i].nearestRiders = (int*)calloc(instance.numRiders, sizeof(int));
		}
		generateDR(&instance, drivers, riders, numDrivers, numRiders);
	}
	instance.dist = (double*)calloc(instance.nnodes * instance.nnodes, sizeof(double));
	for (int i = 0; i < instance.nnodes; i++)
	{
		for (int j = 0; j < instance.nnodes; j++)
		{
			distance(i, j, &instance);
		}
	}
	instance.best_sol = (int*)calloc(instance.nnodes, sizeof(int));
	
	if (strcmp(instance.cplex, "cplex") == 0)
	{
		clock_t begin = clock();
		int* p = NULL;
		CSopt(&instance, drivers, riders, numDrivers);
		clock_t end = clock();
		printf("\nElapsed time: %f\n", (double)((end - begin)) / CLOCKS_PER_SEC);
	}

	for (int i = 0; i < numDrivers; i++)
	{
		//plot(drivers[i].file, i);
		/*int k = findNearestRiders(&instance, drivers[i], riders);
		for (int j = 0; j < k; j++)
		{
			printf("Rider at node %d is near driver at node %d\n", drivers[i].nearestRiders[j], drivers[i].startingNode);
		}*/
	}

	free(instance.best_sol);
	free(riders);
	if (pcl == 0)
	{
		for (int i = 0; i < numDrivers; i++)
		{
			free(drivers[i].path);
			free(drivers[i].nearestRiders);
		}
	}
	free(drivers);
	free_memory(&instance);
}
