#include <cplex.h>  
#include "carsharing.h"
#include "utilities.h"
#define VERBOSE 10


void print_error(const char* err)
{
	printf("\n\n ERROR: %s \n\n", err);
	fflush(NULL);
	exit(1);
}

//other prototypes 

int xpos(int i, int j, Instance* inst)                                          
/***************************************************************************************************************************/
{
	if (i == j) print_error(" i == j in xpos");
	if (i > j) return xpos(j, i, inst);
	int pos = i * inst->nnodes + j - ((i + 1) * (i + 2)) / 2;
	return pos;
}


/***************************************************************************************************************************/
void buildSPPModel(Instance* inst, CPXENVptr env, CPXLPptr lp, Driver drivers)
/**************************************************************************************************************************/
{

	double zero = 0.0;
	char binary = 'B';

	char** cname = (char**)calloc(1, sizeof(char*));		// (char **) required by cplex...
	cname[0] = (char*)calloc(100, sizeof(char));

	// add binary var.s x(i,j) for i < j  

	for (int i = 0; i < inst->nnodes; i++)
	{
		for (int j = i+1; j < inst->nnodes; j++)
		{
			sprintf(cname[0], "x(%d,%d)", i + 1, j + 1);  		// ... x(1,2), x(1,3) ....
			double obj = inst->dist[i * inst->nnodes + j]; // cost == distance   
			double lb = 0.0;
			double ub = 1.0;
			if (CPXnewcols(env, lp, 1, &obj, &lb, &ub, &binary, cname)) print_error(" wrong CPXnewcols on x var.s");
			if (CPXgetnumcols(env, lp) - 1 != xpos(i, j, inst)) print_error(" wrong position for x var.s");
		}
	}

	// add the degree constraints 

	int* index = (int*)calloc(inst->nnodes, sizeof(int));
	double* value = (double*)calloc(inst->nnodes, sizeof(double));

	for (int h = 0; h < inst->nnodes; h++)  		// add the degree constraint on node h
	{
		double rhs;
		if (h == drivers.startingNode)
		{
			rhs = 1.0;
		}
		else if (h == drivers.arrivalNode)
		{
			rhs = 1.0;
		}
		else
		{
			rhs = 2.0;
		}
		char sense = 'E';                            // 'E' for equality constraint 
		sprintf(cname[0], "degree(%d)", h + 1);
		int nnz = 0;
		for (int i = 0; i < inst->nnodes; i++)
		{
			if (i == h) continue;
			index[nnz] = xpos(i, h, inst);
			value[nnz] = 1.0;
			nnz++;
		}
		int izero = 0;
		if (CPXaddrows(env, lp, 0, 1, nnz, &rhs, &sense, &izero, index, value, NULL, &cname[0])) print_error("CPXaddrows(): error 1");
	}

	free(value);
	free(index);

	free(cname[0]);
	free(cname);

	if (VERBOSE >= 100)
	{
		int status = CPXwriteprob(env, lp, "model.lp", NULL);
		if (status)
		{
			printf("Status error: %d\n", status);
			exit(1);
		}
	}

}

//#define DEBUG    // comment out to avoid debugging 
#define EPS 1e-5

// Bender's loop method:
// receives integer solution made of one or mode cycles
// when I enter the method I assume nonzero elements of xstar are one

/*********************************************************************************************************************************/
void build_sol(const double* xstar, Instance* inst, int* succ, int* index, Driver drivers) // build succ() and comp() wrt xstar()...
/*********************************************************************************************************************************/
{

#ifdef DEBUG // I check if degree of all nodes is two and if xstar does not contain fract. components
	int* degree = (int*)calloc(inst->nnodes, sizeof(int));
	for (int i = 0; i < inst->nnodes; i++)
	{
		for (int j = i + 1; j < inst->nnodes; j++)
		{
			int k = xpos(i, j, inst);
			if (fabs(xstar[k]) > EPS && fabs(xstar[k] - 1.0) > EPS) print_error(" wrong xstar in build_sol()");
			if (xstar[k] > 0.5)
			{
				++degree[i];
				++degree[j];
			}
		}
	}
	for (int i = 0; i < inst->nnodes; i++)
	{
		if (degree[i] != 2) print_error("wrong degree in build_sol()");
	}
	free(degree);
#endif

	
	for (int i = 0; i < inst->nnodes; i++)
	{
		succ[i] = -1;
	}

	int tmp = drivers.startingNode;
	int iindex = 0;
	while (1)
	{
		succ[iindex] = tmp;
		if (tmp == drivers.arrivalNode)
		{
			break;
		}
		for (int i = 0; i < inst->nnodes; i++)
		{
			if (i != tmp && xstar[xpos(tmp, i, inst)] > 0.5)
			{
				int flag = 0;
				for (int j = 0; j <= iindex; j++)
				{
					if (i == succ[j])
					{
						flag = 1;
						break;
					}
				}
				if (flag == 1)
				{
					continue;
				}
				else
				{
					tmp = i;
					iindex += 1;
					break;
				}
			}
		}
	}
	*index = iindex;
}

/**************************************************************************************************************************/
int CSopt(Instance* inst, Driver* drivers, Rider* riders, int numDrivers)
/**************************************************************************************************************************/
{
	for (int it = 0; it < numDrivers; it++)
	{
		// open CPLEX model
		int error;
		CPXENVptr env = CPXopenCPLEX(&error);
		if (error) print_error("CPXopenCPLEX() error");
		CPXLPptr lp = CPXcreateprob(env, &error, "CS model version 1");
		if (error) print_error("CPXcreateprob() error");

		buildSPPModel(inst, env, lp, drivers[it]);

		// Cplex's parameter setting
		CPXsetintparam(env, CPX_PARAM_SCRIND, CPX_OFF);
		if (VERBOSE >= 60) CPXsetintparam(env, CPX_PARAM_SCRIND, CPX_ON); // Cplex output on screen
		CPXsetintparam(env, CPX_PARAM_RANDOMSEED, 123456);
		CPXsetdblparam(env, CPX_PARAM_TILIM, 3600.0);
		// ...

		error = CPXmipopt(env, lp);
		if (error)
		{
			printf("CPX error code %d\n", error);
			print_error("CPXmipopt() error");
		}

		// use the optimal solution found by CPLEX

		int ncols = CPXgetnumcols(env, lp);
		double* xstar = (double*)calloc(ncols, sizeof(double));
		error = CPXgetx(env, lp, xstar, 0, ncols - 1);
		if (error)
		{
			printf("CPXgetx() error: %d\n", error);
			print_error("CPXgetx() error");
		}
		//for (int i = 0; i < inst->nnodes; i++)
		//{
		//	for (int j = i + 1; j < inst->nnodes; j++)
		//	{
		//		//if (xstar[xpos(i, j, inst)] > 0.5) printf("  ... x(%3d,%3d) = 1\n", i + 1, j + 1);
		//	}
		//}
		int* succ = (int*)calloc(inst->nnodes, sizeof(int));
		int index = 0;
		char sense = 'L';
		char** cname = (char**)calloc(1, sizeof(char*));		// (char **) required by cplex...
		cname[0] = (char*)calloc(inst->nnodes, sizeof(char));
		int izero = 0;
		int Sname = 0;

		build_sol(xstar, inst, succ, &index, drivers[it]);

		for (int i = 0; i <= index; i++)
		{
			drivers[it].path[i] = succ[i];
		}
		drivers[it].pathCardinality = index;
		
		sprintf(drivers[it].file, "Path of driver%d.dat", it);
		if (it < 10)
		{
			drivers[it].file[15] = '\0';
		}
		else if (it > 9 && it < 100)
		{
			drivers[it].file[16] = '\0';
		}
		else
		{
			drivers[it].file[17] = '\0';
		}
		
		writeOnFile(inst, drivers[it]);

		free(xstar);
		free(succ);
		free(cname[0]);
		free(cname);
		// free and close cplex model   
		CPXfreeprob(env, &lp);
		CPXcloseCPLEX(&env);
	}

	return 0; // or an appropriate nonzero error code
}
/***************************************************************************************************************************/
