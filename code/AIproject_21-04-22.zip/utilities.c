#include "utilities.h"
#define MIN(a,b) ( ((a) < (b)) ? (a) : (b) )

void free_memory(Instance* instance)
{
	free(instance->xcoord);
	free(instance->ycoord);
	free(instance->dist);
	//free(instance->tabuSucc);
	//free(instance->best_succ);
	//free(instance->best_sol);
}

int parse_command_line(int argc, char** argv, Instance* instance)
{
	int return_value = 0;
	//default values
	strcpy(instance->input_file, "NULL");
	//printf("Number of args: %d", argc);
	//printf("%s", *argv);

	for (int i = 1; i < argc; i++)
	{
		if (strcmp("-f", argv[i]) == 0)
		{
			strcpy(instance->input_file, argv[++i]);
			return_value += 1;
			continue;
		}
		if (strcmp("-C", argv[i]) == 0) //Cplex
		{
			strcpy(instance->cplex, argv[++i]);
			continue;
		}
		if (strcmp("-r", argv[i]) == 0) //random nodes
		{
			char* num = argv[++i];
			instance->nrnodes = atoi(num);
			printf("Number of random nodes: %d\n", instance->nrnodes);
		}
	}
	return return_value;
}

void read_input(Instance* instance)
{
	FILE* finput = fopen(instance->input_file, "r");
	FILE* fout = fopen("Output.txt", "w");
	//buffer for fgets()
	char line[200];
	//pointer for strtok()
	char* token;
	//flag to start storing coordinates
	int coordinates = 0;

	while (fgets(line, 200, finput) != NULL)
	{
		token = strtok(line, " :");

		if (strncmp(token, "NAME", 4) == 0)
		{
			char* name = strtok(NULL, " :");
			printf("NAME: %s", name);
			coordinates = 0;
			int len = strlen(name);
			if (len > 0 && name[len - 1] == '\n') name[len - 1] = '\0';
			strcpy(instance->solution_file, name);
			strcat(strcat(instance->solution_file, instance->cplex),".dat");
			printf("%s\n", instance->solution_file);
			continue;
		}

		if (strncmp(token, "DIMENSION", 9) == 0)
		{
			char* tmp = strtok(NULL, " :");
			instance->nnodes = atoi(tmp);
			int nn = instance->nnodes;
			instance->xcoord = (double*)calloc(nn, sizeof(double));
			instance->ycoord = (double*)calloc(nn, sizeof(double));
			instance->dist = (double*)calloc(nn * nn, sizeof(double));
			coordinates = 0;
		}

		if (strncmp(token, "NODE_COORD_SECTION", 18) == 0)
		{
			coordinates = 1;
			continue;
		}

		if (coordinates == 1)
		{
			char* x;
			char* y;
			char out[100];
			int i = atoi(token) - 1;
			if (i < 0 || i >= instance->nnodes)
			{
				coordinates = 0;
				continue;
			}
			x = strtok(NULL, " ");
			y = strtok(NULL, " ");
			instance->xcoord[i] = atof(x);
			instance->ycoord[i] = atof(y);
			snprintf(out, sizeof(out), "%s%s%s%s%s%s", token, ": ", x, " ", y, "\n");
			fputs(out, fout);
			//printf("Node %d at coordinates %f , %f\n", i, instance->xcoord[i], instance->ycoord[i]);
			continue;
		}
	}
	fclose(finput);
	fclose(fout);
}

void generate_random_points(Instance* instance)
{
	srand(10);
	for (int i = 0; i < 1000; i++) rand();
	
	int n = instance->nrnodes;

	instance->xcoord = (double*)calloc(n, sizeof(double));
	instance->ycoord = (double*)calloc(n, sizeof(double));
	for (int i = 0; i < n; i++)
	{
		instance->xcoord[i] = rand() % 6000;
		instance->ycoord[i] = rand() % 6000;
		//printf("Node %d at coordinates %f , %f\n", i, instance->xcoord[i], instance->ycoord[i]);
	}
	instance->nnodes = instance->nrnodes;

}

void generateDR(Instance* instance, Driver* drivers, Rider* riders, int numDrivers, int numRiders)
{
	int* isUsed = (int*)calloc(instance->nnodes, sizeof(int));

	for (int i = 0; i < instance->nnodes; i++)
	{
		isUsed[i] = -1;
	}

	for (int i = 0; i < numDrivers; i++)
	{
		while (1)
		{
			int rv = rand() % instance->nnodes;
			if (isUsed[rv] == -1)
			{
				drivers[i].startingNode = rv;
				isUsed[rv] = 1;
				break;
			}
		}
	}
	for (int i = 0; i < numDrivers; i++)
	{
		while (1)
		{
			int rv = rand() % instance->nnodes;
			if (rv !=drivers[i].startingNode)
			{
				drivers[i].arrivalNode = rv;
				break;
			}
		}
	}
	for (int i = 0; i < instance->nnodes; i++)
	{
		isUsed[i] = -1;
	}
	for (int i = 0; i < numRiders; i++) // to increase diversity
	{
		while (1)
		{
			int rv = rand() % instance->nnodes;
			if (isUsed[rv] == -1)
			{
				riders[i].startingNode = rv;
				isUsed[rv] = 1;
				break;
			}
		}
	}
	for (int i = 0; i < numRiders; i++)
	{
		while (1)
		{
			int rv = rand() % instance->nnodes;
			if (rv != riders[i].startingNode)
			{
				riders[i].arrivalNode = rv;
				break;
			}
		}
	}
	free(isUsed);
}

void distance(int i, int j, Instance* instance)
{
	if (i == j)
	{
		instance->dist[i * instance->nnodes + j] = 0;
	}
	else
	{
		double xdist = instance->xcoord[i] - instance->xcoord[j];
		double ydist = instance->ycoord[i] - instance->ycoord[j];
		double distance = sqrt(xdist * xdist + ydist * ydist);
		instance->dist[i * instance->nnodes + j] = distance;
	}

}

int findNode(Instance* instance, double xCoord)
{
	for (int i = 0; i < instance->nnodes; i++)
	{
		if (instance->xcoord[i] == xCoord)
		{
			return i;
		}
	}
}

void writeOnFile(Instance* instance, Driver drivers)
{
	FILE* fout = fopen(drivers.file, "w");
	//array in which we write the coordinates; may be useless because we can just use best_sol to get the coordinates.
	double solution[2000];

	//now the nodes in instance->best_sol are ordered : index 0 contains the first node, index 1 contains the successor of the node in position 0 and so on

	//this for and the two lines following it are used to write the minimum cost solution into the output file
	for (int i = 0; i <= drivers.pathCardinality; i++)
	{
		snprintf(solution, sizeof(solution), "%f%s%f%s", instance->xcoord[drivers.path[i]], " ", instance->ycoord[drivers.path[i]], "\n");
		fputs(solution, fout);
	}
	fclose(fout);
}

void updatePath(Instance* instance, Driver drivers, int riderNode)
{
	double dist = MAX_VAL;
	int pathNode = 0;
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		double tmp = instance->dist[drivers.path[i] * instance->nnodes + riderNode];
		if (tmp < dist)
		{
			dist = tmp;
			pathNode = i;
		}
	}
	int* stack = (int*)calloc(drivers.pathCardinality + 1, sizeof(int));
	int flag = 0;
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		if (flag)
		{
			stack[i + 1] = drivers.path[i];
		}
		else
		{
			stack[i] = drivers.path[i];
			if (i == pathNode)
			{
				stack[i + 1] = riderNode;
				flag = 1;
			}
		}
	}
	drivers.pathCardinality += 1;
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		drivers.path[i] = stack[i];
	}

	free(stack);
	writeOnFile(instance, drivers);
}

void plot(char* fileName, int driverNum)
{
	FILE* pipe = _popen("C:/Programmi/gnuplot/bin/gnuplot.exe -persist", "w");
	if (pipe != NULL)
	{
		fprintf(pipe, "plot '%s' with linespoints linestyle 6 \n", fileName);
		fflush(pipe);
	}
	else puts("Could not open the file\n");
	_pclose(pipe);
}

int findNearestRiders(Instance* instance, Driver drivers, Rider* riders)
{
	drivers.radius = 1500;
	int index = 0;
	for (int i = 0; i < instance->numRiders; i++)
	{
		drivers.nearestRiders[i] = -1;
	}
	for (int i = 0; i < drivers.pathCardinality; i++)
	{
		for (int j = 0; j < instance->numRiders; j++)
		{
			if (instance->dist[drivers.path[i] * instance->nnodes + riders[j].startingNode] <= drivers.radius)
			{
				int flag = 1;
				for (int k = 0; k < instance->numRiders; k++)
				{
					if (drivers.nearestRiders[k] == j)
					{
						flag = 0;
					}
				}
				if (flag)
				{
					drivers.nearestRiders[index] = j;
					index += 1;
				}
			}
		}
	}
	return index;
}

